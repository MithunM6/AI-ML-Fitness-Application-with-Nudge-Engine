import mysql.connector
import pandas as pd

host = '127.0.0.1'
user = 'root'
password = 'root'
database = 'aiml'

# Establishing the connection
conn = mysql.connector.connect(
    host=host,
    user=user,
    password=password,
    database=database,
    auth_plugin='mysql_native_password'
)

# Creating a cursor object
cursor = conn.cursor()

# SQL query to insert data
in_q = '''
INSERT INTO nudge (User_Id, User_Name, Nudge_Id) VALUES (%s, %s, %s)
'''

# Values to be inserted
U_id = int(input("enter user id --> "))
U_n = input("enter name --->  ")
N_id = int(input("enter nudge engine id -->"))
in_v = (U_id, U_n,N_id)

# Executing the query
cursor.execute(in_q, in_v)

# Committing the transaction
conn.commit()

# Closing the connection and cursor
cursor.close()
conn.close()

print("Data saved successfully")
