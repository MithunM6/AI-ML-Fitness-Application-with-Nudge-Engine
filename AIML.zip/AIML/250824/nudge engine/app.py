from flask import Flask, request, jsonify, render_template, redirect, url_for
from models import db, User, Nudge, UserActivity
from nudge_engine import NudgeEngine
from ai_ml import NudgePredictor

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@127.0.0.1/nudge_engine_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

nudge_engine = NudgeEngine()
nudge_predictor = NudgePredictor()

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    user = User.query.filter_by(username=username, password=password).first()
    if user:
        return redirect(url_for('dashboard', user_id=user.user_id))
    else:
        return 'Login Failed'

@app.route('/dashboard/<int:user_id>')
def dashboard(user_id):
    user = User.query.get(user_id)
    nudges = Nudge.query.filter_by(user_id=user_id).all()
    return render_template('dashboard.html', user=user, nudges=nudges)

@app.route('/admin')
def admin():
    nudges = Nudge.query.all()
    return render_template('admin.html', nudges=nudges)

@app.route('/api/nudges', methods=['POST'])
def create_nudge():
    user_id = request.json['user_id']
    nudge_type = request.json['nudge_type']
    message = request.json['message']
    trigger_time = request.json['trigger_time']
    nudge = Nudge(user_id=user_id, nudge_type=nudge_type, message=message, trigger_time=trigger_time)
    db.session.add(nudge)
    db.session.commit()
    return jsonify({'status': 'Nudge created successfully'}), 201

if __name__ == '__main__':
    app.run(debug=True)
