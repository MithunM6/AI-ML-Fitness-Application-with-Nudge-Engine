from datetime import datetime
from models import db, Nudge, UserActivity

class NudgeEngine:
    def check_triggers(self):
        nudges = Nudge.query.filter_by(is_triggered=False).all()
        for nudge in nudges:
            if nudge.trigger_time <= datetime.now():
                self.send_nudge(nudge)

    def send_nudge(self, nudge):
        # Logic to send nudge (e.g., push notification, email)
        nudge.is_triggered = True
        db.session.commit()

    def schedule_nudges(self, user_id):
        # Example: Schedule a nudge if the user hasn't reached their step goal
        user_activity = UserActivity.query.filter_by(user_id=user_id, activity_type='steps').order_by(UserActivity.timestamp.desc()).first()
        if user_activity and user_activity.activity_value < 10000:
            nudge = Nudge(user_id=user_id, nudge_type='steps', message='You haven’t met your step goal today. Take a walk!')
            db.session.add(nudge)
            db.session.commit()
