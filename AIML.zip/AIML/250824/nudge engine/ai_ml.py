from sklearn.tree import DecisionTreeClassifier
import numpy as np

class NudgePredictor:
    def __init__(self):
        self.model = DecisionTreeClassifier()

    def train_model(self, X, y):
        self.model.fit(X, y)

    def predict_nudge(self, user_data):
        return self.model.predict(np.array(user_data).reshape(1, -1))
