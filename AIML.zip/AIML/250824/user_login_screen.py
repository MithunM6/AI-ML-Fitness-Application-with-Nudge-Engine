import mysql.connector
import tkinter as tk
from tkinter import messagebox

# Function to verify login credentials
def verify_login():
    username = entry_username.get()
    password = entry_password.get()
    
    # Here you should validate the username and password.
    # For this example, we are using hardcoded credentials.
    if username == "admin" and password == "password":
        login_screen.destroy()  # Close the login window
        open_data_entry()  # Open the data entry window
    else:
        messagebox.showerror("Error", "Invalid username or password")

# Function to open the data entry screen
def open_data_entry():
    data_entry_screen = tk.Tk()
    data_entry_screen.title("Fitwithmithun")

    # Creating labels and entry fields
    label_user_id = tk.Label(data_entry_screen, text="User ID")
    label_user_id.grid(row=0, column=0, padx=10, pady=10)
    entry_user_id = tk.Entry(data_entry_screen)
    entry_user_id.grid(row=0, column=1, padx=10, pady=10)

    label_user_name = tk.Label(data_entry_screen, text="User Name")
    label_user_name.grid(row=1, column=0, padx=10, pady=10)
    entry_user_name = tk.Entry(data_entry_screen)
    entry_user_name.grid(row=1, column=1, padx=10, pady=10)

    label_nudge_id = tk.Label(data_entry_screen, text="Nudge ID")
    label_nudge_id.grid(row=2, column=0, padx=10, pady=10)
    entry_nudge_id = tk.Entry(data_entry_screen)
    entry_nudge_id.grid(row=2, column=1, padx=10, pady=10)

    # Function to insert data into the MySQL database
    def insert_data():
        try:
            # Establishing the connection
            conn = mysql.connector.connect(
                host='127.0.0.1',
                user='root',
                password='root',
                database='aiml',
                auth_plugin='mysql_native_password'
            )

            # Creating a cursor object
            cursor = conn.cursor()

            # SQL query to insert data
            in_q = '''
            INSERT INTO nudge (User_Id, User_Name, Nudge_Id,Arms workout,Suryanamaskar,Abs, Chest workout, Leg workout, Shoulder workout,
            Back workout, Fullbody workout) VALUES (%s, %s, %s,%s, %s, %s, %s, %s,%s, %s, %s)
            '''

            # Fetching values from the entry fields
            U_id = int(entry_user_id.get())
            U_n = entry_user_name.get()
            N_id = int(entry_nudge_id.get())

            # Values to be inserted
            in_v = (U_id, U_n, N_id)

            # Executing the query
            cursor.execute(in_q, in_v)

            # Committing the transaction
            conn.commit()

            # Closing the connection and cursor
            cursor.close()
            conn.close()

            # Showing success message
            messagebox.showinfo("Success", "Data saved successfully")

        except Exception as e:
            # Showing error message
            messagebox.showerror("Error", str(e))

    # Creating the submit button
    submit_button = tk.Button(data_entry_screen, text="Submit", command=insert_data)
    submit_button.grid(row=3, column=0, columnspan=2, pady=20)

    # Running the application
    data_entry_screen.mainloop()

# Creating the login screen
login_screen = tk.Tk()
login_screen.title("User Login")

# Creating labels and entry fields for username and password
label_username = tk.Label(login_screen, text="Username")
label_username.grid(row=0, column=0, padx=10, pady=10)
entry_username = tk.Entry(login_screen)
entry_username.grid(row=0, column=1, padx=10, pady=10)

label_password = tk.Label(login_screen, text="Password")
label_password.grid(row=1, column=0, padx=10, pady=10)
entry_password = tk.Entry(login_screen, show="*")
entry_password.grid(row=1, column=1, padx=10, pady=10)

# Creating the login button
login_button = tk.Button(login_screen, text="Login", command=verify_login)
login_button.grid(row=2, column=0, columnspan=2, pady=20)

# Running the login application
login_screen.mainloop()

