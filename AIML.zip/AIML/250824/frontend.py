import mysql.connector
import tkinter as tk
from tkinter import messagebox

def insert_data():
    try:
        # Establishing the connection
        conn = mysql.connector.connect(
            host='127.0.0.1',
            user='root',
            password='root',
            database='aiml',
            auth_plugin='mysql_native_password'
        )

        # Creating a cursor object
        cursor = conn.cursor()

        # SQL query to insert data
        in_q = '''
        INSERT INTO nudge (User_Id, User_Name, Nudge_Id) VALUES (%s, %s, %s)
        '''

        # Fetching values from the entry fields
        U_id = int(entry_user_id.get())
        U_n = entry_user_name.get()
        N_id = int(entry_nudge_id.get())

        # Values to be inserted
        in_v = (U_id, U_n, N_id)

        # Executing the query
        cursor.execute(in_q, in_v)

        # Committing the transaction
        conn.commit()

        # Closing the connection and cursor
        cursor.close()
        conn.close()

        # Showing success message
        messagebox.showinfo("Success", "Data saved successfully")

    except Exception as e:
        # Showing error message
        messagebox.showerror("Error", str(e))

# Creating the main window
root = tk.Tk()
root.title("Nudge Data Entry")

# Creating labels and entry fields
label_user_id = tk.Label(root, text="User ID")
label_user_id.grid(row=0, column=0, padx=10, pady=10)
entry_user_id = tk.Entry(root)
entry_user_id.grid(row=0, column=1, padx=10, pady=10)

label_user_name = tk.Label(root, text="User Name")
label_user_name.grid(row=1, column=0, padx=10, pady=10)
entry_user_name = tk.Entry(root)
entry_user_name.grid(row=1, column=1, padx=10, pady=10)

label_nudge_id = tk.Label(root, text="Nudge ID")
label_nudge_id.grid(row=2, column=0, padx=10, pady=10)
entry_nudge_id = tk.Entry(root)
entry_nudge_id.grid(row=2, column=1, padx=10, pady=10)

# Creating the submit button
submit_button = tk.Button(root, text="Submit", command=insert_data)
submit_button.grid(row=3, column=0, columnspan=2, pady=20)

# Running the application
root.mainloop()
